#!/usr/bin/env python3
import json,pathlib,re,shutil,sys
extension=pathlib.Path(__file__).resolve().parent.parent
site=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else None
if not site or not (site/'js/app.js').exists():
 raise SystemExit('Usage : python installer.py /chemin/vers/03_SITE_COMPLET')
books=json.loads((extension/'integration/nouveaux-livres.json').read_text(encoding='utf-8'))
app=site/'js/app.js'; source=app.read_text(encoding='utf-8')
start=source.index('const LIVRES_INITIAUX=')+len('const LIVRES_INITIAUX=')
end=source.index('\n];',start)+2
existing=json.loads(source[start:end]); known={x['id'] for x in existing}
for b in books:
 if b['id'] not in known: existing.append({k:v for k,v in b.items() if k!='chapters'})
source=source[:start]+json.dumps(existing,ensure_ascii=False,indent=2)+source[end:]
app.write_text(source,encoding='utf-8')
cat=site/'catalogue-documente.json'
if cat.exists():
 data=json.loads(cat.read_text(encoding='utf-8')); ids={x['id'] for x in data};data.extend({k:v for k,v in b.items() if k!='chapters'} for b in books if b['id'] not in ids);cat.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
for b in books:
 for rel in [b['pdfPath'],b['cover']]:
  dest=site/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(extension/rel,dest)
 src=extension/'ouvrages'/b['detailPath'];shutil.copy2(src,site/b['detailPath'])
print('Ajout terminé : 6 livres. Tester les comptes et le lecteur sur un serveur HTTP avant publication.')
