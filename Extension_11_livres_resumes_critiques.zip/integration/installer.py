#!/usr/bin/env python3
import json,sys,shutil,re
from pathlib import Path
src=Path(__file__).resolve().parents[1]
if len(sys.argv)!=2:raise SystemExit('Usage: python integration/installer.py CHEMIN_SITE')
root=Path(sys.argv[1]).resolve(); app=root/'js/app.js';cat=root/'catalogue-documente.json'
if not app.is_file() or not cat.is_file():raise SystemExit('Le dossier fourni ne contient pas le site attendu.')
new=json.loads((src/'integration/nouveaux-livres.json').read_text());existing=json.loads(cat.read_text());s=app.read_text()
ids={b['id'] for b in new}
if ids & {b['id'] for b in existing}:raise SystemExit('Des livres de cette extension sont déjà installés. Aucune modification.')
if s.count('const LIVRES_INITIAUX=[')!=1:raise SystemExit('Catalogue JS introuvable.')
for b in new:
 for rel in (b['pdfPath'],b['cover'],b['detailPath']):
  dest=root/rel
  if dest.exists():raise SystemExit('Fichier cible déjà présent : '+rel)
for b in new:
 for rel in (b['pdfPath'],b['cover'],b['detailPath']):
  dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/rel,dest)
existing.extend(new);cat.write_text(json.dumps(existing,ensure_ascii=False,indent=2)+'\n')
addition=',\n'.join(json.dumps(b,ensure_ascii=False,indent=2) for b in new)
s=s.replace('const LIVRES_INITIAUX=[','const LIVRES_INITIAUX=[\n'+addition+',',1);app.write_text(s)
print('11 livres installés ; total catalogue :',len(existing))
